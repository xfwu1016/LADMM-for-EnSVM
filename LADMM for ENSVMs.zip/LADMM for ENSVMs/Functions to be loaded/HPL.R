HPL=function(x,mu,de,tau){
  u=rep(0,length(x))
  for(i in 1:length(x)){
    if(x[i]>(1/(n*mu)+de)){u[i]=x[i]-1/(n*mu)}else if((x[i]>0)&(x[i]<=(1/(n*mu)+de))){
      u[i]=n*de*mu*x[i]/(n*de*mu+1)}else if(x[i]<=-tau/(n*mu)-de){
        u[i]=x[i]+tau/(n*mu)}else{
          u[i]=n*de*mu*x[i]/(n*de*mu+tau)} 
      }
  return(u)
}