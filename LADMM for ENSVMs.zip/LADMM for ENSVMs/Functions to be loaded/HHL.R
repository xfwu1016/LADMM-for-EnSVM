HHL=function(x,mu){
  u=rep(0,length(x))
  for(i in 1:length(x)){
    u[i]=max(x[i]-1/(n*mu),min(x[i],(n*de*mu*x[i])/(1+n*de*mu)))
  }
  return(u)
}