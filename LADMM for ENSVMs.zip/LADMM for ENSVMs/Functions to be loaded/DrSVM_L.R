DrSVM_L=function(y,X,lambda1,lambda2){
n=nrow(X)
p=ncol(X)
mu1<-0.1#0.01����
#gam=matrix(1,ncol=1,nrow=n)
hXX=rbind(cbind(mu1*n,mu1*t(gam)%*%X),cbind(mu1*t(X)%*%gam,mu1*t(X)%*%X+lambda2*diag(1,p)))
######
ite=2000
#
eta=pmethod(A=hXX,x=rep(1,ncol(hXX)),ite=1000)[1]
eta=0.76*eta+0.05
#update beta
beta0<-rep(0,p+1)
r0=y-X%*%beta0[2:(p+1)]
u0=rep(0.000,n)
beta_M<-matrix(0.000,p+1,ite+1)
r_M<-matrix(0.000,n,ite+1)
u_M<-matrix(0.000,n,ite+1)
beta_M[,1]=beta0
r_M[,1]=r0
u_M[,1]=u0
#��¼�в�
A=cbind(gam,X)
B=diag(n)
pri=rep(0,ite+1)
dua=rep(0,ite+1)
#
k=0
repeat{
 #ԭ��������
 f_k=(hXX%*%beta_M[,k+1]-mu1*rbind(t(gam)%*%(y+1/mu1*u_M[,k+1]-r_M[,k+1]),t(X)%*%(y+1/mu1*u_M[,k+1]-r_M[,k+1])))/eta
 beta0_u=beta_M[,k+1][1]-f_k[1]
 beta_u=Thld(beta_M[,k+1][2:(p+1)]-f_k[2:(p+1)],lambda1,eta)
 r_u=HL(y-X%*%beta_u-beta0_u*gam+u_M[,k+1]/mu1,mu1)
 #��ż��������
 #mu1=muad(mu1,c(beta0_u,beta_u),r_M[,k+1] ,r_u,A,B,b)*mu1
 u_u=u_M[,k+1]-mu1*(r_u-y+X%*%beta_u+beta0_u*gam)
#mu1=1.1*mu1
 #k+1����
 k=k+1
 beta_M[,k+1]= c(beta0_u,beta_u)
 r_M[,k+1]=r_u
 u_M[,k+1]=u_u
 #
 pri[k]=sqrt(sum((mu1*t(A)%*%B%*%(r_M[,k+1]-r_M[,k]))^2))
 dua[k]=sqrt(sum((A%*%beta_M[,k+1]+B%*%r_M[,k+1]-y)^2))
 if(10*pri[k]<dua[k]){
   t=2
 }else if(pri[k]>10*dua[k]){
   t=1/2
 }else{t=1}
 mu1=t*mu1
 con1=sqrt(p)*10^-4+10^-4*sqrt(sum((t(A)%*%u_M[,k+1])^2))
 con2=sqrt(n)*10^-4+10^-4*sqrt(max(sum((A%*%beta_M[,k+1])^2),sum((B%*%r_M[,k+1])^2),sum(y^2)))
 
 #
 if(((pri[k]<con1)&(dua[k]<con2))|(k>ite-1)){
   break
 }
}
result=list(beta0= beta0_u,beta_u=beta_u,K=k,pri=pri,dua=dua)
return(result)
}

