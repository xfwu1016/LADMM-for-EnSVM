Thld<-function(x,lambda,mu)
{ r<-rep(0,length(x))
for(i in 1:length(x)){
  r[i]<-sign(x[i])*max(0,abs(x[i])-lambda/mu)}
return(r)
}
