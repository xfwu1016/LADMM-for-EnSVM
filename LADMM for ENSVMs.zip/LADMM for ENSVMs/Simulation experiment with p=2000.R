library(gcdnet)
source("HL.R")#hinge loss
source("LSL.R")#least squares loss
source("SHL.R")#squared hinge loss
source("HPL.R")#huberized pinball loss
source("PL.R")#pinball loss
source("HHL.R")#huberized hinge loss
source("pmethod.R")# power method for the maximum eigenvalue of matrix
source("Thld.R")#soft shrinkage operator
#six ENSVMs
source("LESVM_L.R")
source("DrSVM_L.R")
source("SHSVM_L.R")
source("PESVM_L.R")
source("HHSVM_L.R")
source("HPSVM_L.R")

n=50
p=2000
q=10
rho <- 0.5 #���Ե���0.2,0.4,0.6
#��һ��
x1 <- matrix(rnorm(n*q,0,1), n, q)
x2 <- matrix(rnorm(n*(p-q),0,1), n, p-q)
corrmat1 <- toeplitz(rho^(0:(q-1)))
corrmat2 <- toeplitz(rho^(0:(p-q-1))) 
X_1 <- cbind(x1%*% chol(corrmat1)+1, x2%*% chol(corrmat2))
#�ڶ���
x1 <- matrix(rnorm(n*q,0,1), n, q)
x2 <- matrix(rnorm(n*(p-q),0,1), n, p-q)
corrmat1 <- toeplitz(rho^(0:(q-1)))
corrmat2 <- toeplitz(rho^(0:(p-q-1))) 
X_2 <- cbind(x1%*% chol(corrmat1)-1, x2%*% chol(corrmat2))
########����׼��
X0=rbind(X_1,X_2)
y_label=c(rep(1,n),rep(-1,n))
Y=diag(y_label)
X=Y%*%X0
y=rep(1,length(y_label))
gam=diag(y_label)%*%matrix(1,nrow=length(y),ncol=1)
###test data
nt=500
#��һ��
x1 <- matrix(rnorm(nt*q,0,1), nt, q)
x2 <- matrix(rnorm(nt*(p-q),0,1), nt, p-q)
corrmat1 <- toeplitz(rho^(0:(q-1)))
corrmat2 <- toeplitz(rho^(0:(p-q-1))) 
X_1 <- cbind(x1%*% chol(corrmat1)+1, x2%*% chol(corrmat2))
#�ڶ���
x1 <- matrix(rnorm(nt*q,0,1), nt, q)
x2 <- matrix(rnorm(nt*(p-q),0,1), nt, p-q)
corrmat1 <- toeplitz(rho^(0:(q-1)))
corrmat2 <- toeplitz(rho^(0:(p-q-1))) 
X_2 <- cbind(x1%*% chol(corrmat1)-1, x2%*% chol(corrmat2))
#
X0t=rbind(X_1,X_2)
yt_label=c(rep(1,nt),rep(-1,nt))

##############LESVM
#LADMM
start<-Sys.time()
tau=0.75
LESVM=LESVM_L(y,X,lambda1=1,lambda2=1,tau)#0.2,,0.25
end<-Sys.time()
runningtime<-(end-start)
cat(runningtime)
LESVM$K
beta_c=DrSVM$beta_u
length(which(abs(beta_c)>10^-5))#the number of nonzero
beta_0=LESVM$beta0
length(which(sign(X0%*%beta_c+beta_0)-y_label==0))/(2*n)
length(which(sign(X0t%*%beta_c+beta_0)-yt_label==0))/(2*nt)
plot(LESVM$pri[1:LESVM$K])
plot(LESVM$dua[1:LESVM$K])

###############DrSVM
#LADMM
start<-Sys.time()
DrSVM=DrSVM_L(y,X,lambda1=0.4,lambda2=1)
end<-Sys.time()
runningtime<-(end-start)
cat(runningtime)
DrSVM$K
beta_c=DrSVM$beta_u
length(which(abs(beta_c)>10^-5))#the number of nonzero
beta_0=DrSVM$beta0
length(which(sign(X0%*%beta_c+beta_0)-y_label==0))/(2*n)
length(which(sign(X0t%*%beta_c+beta_0)-yt_label==0))/(2*nt)
plot(DrSVM$pri[1:DrSVM$K])
plot(DrSVM$dua[1:DrSVM$K])

beta_c[1:10]
###############SHSVM
#LADMM
start<-Sys.time()
SHSVM=SHSVM_L(y,X,lambda1=0.55,lambda2=1)
end<-Sys.time()
runningtime<-(end-start)
cat(runningtime)
SHSVM$K
beta_c=SHSVM$beta_u
length(which(abs(beta_c)>10^-5))#the number of nonzero
beta_0=SHSVM$beta0
length(which(sign(X0%*%beta_c+beta_0)-y_label==0))/(2*n)
length(which(sign(X0t%*%beta_c+beta_0)-yt_label==0))/(2*nt)
plot(SHSVM$pri[1:SHSVM$K])
plot(SHSVM$dua[1:SHSVM$K])
beta_c[1:10]


###############PESVM
#LADMM
start<-Sys.time()
tau=0.5
PESVM=PESVM_L(y,X,lambda1=0.5,lambda2=1,tau=0.5)
end<-Sys.time()
runningtime<-(end-start)
cat(runningtime)
PESVM$K
beta_c=PESVM$beta_u
length(which(abs(beta_c)>10^-5))#the number of nonzero
beta_0=PESVM$beta0
length(which(sign(X0%*%beta_c+beta_0)-y_label==0))/(2*n)
length(which(sign(X0t%*%beta_c+beta_0)-yt_label==0))/(2*nt)
plot(PESVM$pri[1:PESVM$K])
plot(PESVM$dua[1:PESVM$K])



###############HHSVM
#LADMM
start<-Sys.time()
de=1
HHSVM=HHSVM_L(y,X,lambda1=0.5,lambda2=1,de=1)
end<-Sys.time()
runningtime<-(end-start)
cat(runningtime)
HHSVM$K
beta_c=HHSVM$beta_u
length(which(abs(beta_c)>10^-5))#the number of nonzero
beta_0=HHSVM$beta0
length(which(sign(X0%*%beta_c+beta_0)-y_label==0))/(2*n)
length(which(sign(X0t%*%beta_c+beta_0)-yt_label==0))/(2*nt)
plot(HHSVM$pri[1:HHSVM$K])
plot(HHSVM$dua[1:HHSVM$K])

start<-Sys.time()
g=gcdnet(X0,y_label,method = "hhsvm",lambda=0.15,lambda2 = 1)
end<-Sys.time()
runningtime<-(end-start)
cat(runningtime)
length(which(abs(as.numeric(g$beta))>10^-5))#the number of nonzero
length(which(sign(X0%*%as.numeric(g$beta)+as.numeric(g$b0))-y_label==0))/(2*n)
length(which(sign(X0t%*%as.numeric(g$beta)+as.numeric(g$b0))-yt_label==0))/(2*nt)

###############HPSVM
#LADMM
start<-Sys.time()
de=1
tau=0.5
HPSVM=HPSVM_L(y,X,lambda1=0.4,lambda2=1,de=1,tau = 0.5)#0.3,0.4,0.4
end<-Sys.time()
runningtime<-(end-start)
cat(runningtime)
HPSVM$K
beta_c=HPSVM$beta_u
length(which(abs(beta_c)>10^-5))#the number of nonzero
beta_0=HPSVM$beta0
length(which(sign(X0%*%beta_c+beta_0)-y_label==0))/(2*n)
length(which(sign(X0t%*%beta_c+beta_0)-yt_label==0))/(2*nt)
plot(HPSVM$pri[1:HPSVM$K])
plot(HPSVM$dua[1:HPSVM$K])

